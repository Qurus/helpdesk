// Merging static files
// Only CSS and JavaScript

// CSS
F.merge('/css/default.css', '/css/bootstrap.min.css', '/css/ui.css', '/css/default.css');
F.merge('/css/login.css', '/css/bootstrap.min.css', '/css/ui.css', '/css/login.css');

// JavaScript
F.merge('/js/default.js', '/js/jctajr.min.js', '/js/ui.js', '/js/default.js');
F.merge('/js/login.js', '/js/jctajr.min.js', '/js/ui.js');